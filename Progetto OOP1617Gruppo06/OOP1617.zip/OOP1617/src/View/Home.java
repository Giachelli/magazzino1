package View;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import com.connectiondb.sqlConnection;

/**
 * Classe Home.java
 * Questa classe implementa la vista della finestra Home base, dove sono presenti
 * oltre alla label di benvenut e al pulsante logout eanche i pulsanti per spostarci nelle varie sezioni:
 * prodotto, dipendenti e turni con le relative dichiarazioni dei metodi.
 *     
 * @author Iezzi Valerio
 *
 */
public class Home implements ActionListener{

	public JFrame frame;
	public Connection connection=sqlConnection.dbConnector();
	public JLabel labelLogin;
	public JButton btnTurni;
	public JButton btnDipendenti;
	public JButton btnLogout;
	public JButton btnProdotto;
	public String id;
	public String label;
	
	public Home() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1280, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		labelLogin = new JLabel();
	    labelLogin.setBounds(143, 7, 61, 16);
	    labelLogin.setFont(new Font("Lucida Grande", Font.BOLD, 16));
	   
	    
	    JLabel lblBenvenuto = new JLabel("Benvenuto,");
		lblBenvenuto.setBounds(39, 6, 92, 16);
		lblBenvenuto.setFont(new Font("Lucida Grande", Font.BOLD, 16));
		frame.getContentPane().add(lblBenvenuto);
				
		btnDipendenti = new JButton("Dipendenti");
		btnDipendenti.setBounds(412, 2, 117, 29);
		frame.getContentPane().add(btnDipendenti);
		
		btnTurni = new JButton("Turni");
		btnTurni.setBounds(522, 2, 117, 29);
		frame.getContentPane().add(btnTurni);
		
		btnLogout = new JButton("Logout");
		btnLogout.setBounds(1182, 2, 92, 29);
		frame.getContentPane().add(btnLogout);
		
		btnProdotto = new JButton("Prodotti");
		btnProdotto.setBounds(300, 2, 117, 29);
		frame.getContentPane().add(btnProdotto);
		
		frame.setTitle("Main Supermercato");
	}

	public void dipendenteView(ActionListener log) {
	  	btnDipendenti.addActionListener(log);
       }
	public void turniView(ActionListener log) {
	  	btnTurni.addActionListener(log);
       }
	public void prodottiView(ActionListener log) {
	  	btnProdotto.addActionListener(log);
       }
	public void Logout (ActionListener log) {
	  	btnLogout.addActionListener(log);
       }

	public void actionPerformed(ActionEvent e) {
    }

	
}
