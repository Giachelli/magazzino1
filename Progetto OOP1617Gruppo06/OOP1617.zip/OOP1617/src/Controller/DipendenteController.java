package Controller;

import java.awt.event.ActionEvent;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import Model.DipendenteModel;
import Model.LoginModel;
import Model.ProdottoModel;
import Model.TurniModel;
import View.DipendenteView;
import View.Home;
import View.LoginView;
import View.ProdottoView;
import View.TurniView;
import net.proteanit.sql.DbUtils;
import Controller.ProdottoController;

/**
 * Classe DipendenteController.java
 * Questa classe ci permette di implementate, richiamando il model, tutte le azioni dei pulsanti
 * realizzati nella view.
 *     
 * @author Iezzi Valerio
 *
 */
public class DipendenteController extends Home {
	
		private DipendenteModel model;   
	    private DipendenteView view;
	    private ProdottoController theController1;
	    private TurniController theController2;
	    
	    public DipendenteController(DipendenteView view){
	        this.view = view;
	        
	        view.addNomeDipendenteListener(new DipendenteListener());
	    	view.addCercaMansioneListener(new CercaMansioneListener());
	    	view.addInserisciDipendenteListener(new InserisciDipendenteListener());
	    	view.addModificaListener(new ModificaDipendente());
	    	view.addCaricaListener(new CaricaDipendenti());
		    view.addCaricaListener_1(new CaricaDipendenti_1());
		    view.addEliminaListener(new EliminaDipendente());
		    view.Logout(new Logout());
	    	view.dipendenteView(new dipendenteView());
	    	view.turniView(new turniView());
	    	view.prodottiView(new prodottiView());
	    } 
	    
	    class turniView implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		

	    		TurniView theView = new TurniView();
	    		@SuppressWarnings("unused")
				TurniModel theModel= new TurniModel(); 
	    		theController2= new TurniController(theView);
	    		theController2.id=id;
	    		theController2.label=label;
	    		labelLogin.setText(label);
	    		theView.frame.add(labelLogin);
	    		theView.frame.setVisible(true);
	    		view.frame.dispose();
	    		
	    	}
	    }
	    
	    class prodottiView implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		
	    		ProdottoView theView = new ProdottoView();
	    		@SuppressWarnings("unused")
	    		ProdottoModel theModel= new ProdottoModel(); 
	    		theController1= new ProdottoController(theView);
	    		theController1.id=id;
	    		theController1.label=label;
	    		labelLogin.setText(label);
	    		theView.frame.add(labelLogin);
	    		theView.frame.setVisible(true);
	    		view.frame.dispose();
	    		
	    	}
	    }
	    
	    class dipendenteView implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		
	    		DipendenteView theView = new DipendenteView();
	    		@SuppressWarnings("unused")
	    		DipendenteModel theModel= new DipendenteModel(); 
	    		DipendenteController theController= new DipendenteController(theView);
	    		theController.id=id;
	    		theController.label=label;
	    		labelLogin.setText(label);
	    		theView.frame.add(labelLogin);
	    		theView.frame.setVisible(true);
	    		view.frame.dispose();
	    	}
	    }
	   
	    
	   
	    class Logout implements ActionListener {
	    	public void actionPerformed(ActionEvent e){
	    		
				try {
					connection.close();
					view.frame.dispose();
					
					LoginView theView = new LoginView();
					@SuppressWarnings("unused")
					LoginModel theModel = new LoginModel(); 
					@SuppressWarnings("unused")
					LoginController theController = new LoginController(theView);
					
					theView.frameLogin.setVisible(true);
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
	    		
	    }}
	    
	    
	    class EliminaDipendente implements ActionListener {  
	    	public void actionPerformed(ActionEvent e){
	    		int action=JOptionPane.showConfirmDialog
						(null, "Sei sicuro di voler eliminare il dipendente selezionato?","Elimina", JOptionPane.YES_NO_OPTION);
				if (action==0){
				try{
				
					int row=view.tabella.getSelectedRow();
					String codice_=(view.tabella.getModel().getValueAt(row, 0)).toString();
					
					String query="Delete from Dipendente where codice='"+codice_+"'";
					
					PreparedStatement pst=connection.prepareStatement(query);
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Dipendente eliminato correttamente!");
					pst.close();
					view.refreshTabella(id);
					view.refreshForm();
						}catch(Exception e1){
							JOptionPane.showMessageDialog(null, "Impossibile eliminare: selezionare il dipendente!");
							
						}
				}
	    }}
	    
	  
	    class CaricaDipendenti implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		
	    		String mansione;
	    		String nome;
	    		String sql;
	    		
	    		model=view.getDipendente4();
	    		mansione=model.getMansione();
	    		nome=model.getNomeDipendente();
	    		
	    		try {
	    			if(nome.equals("")==true && mansione.equals("")==true) {
	    				sql=null;
	    			}else if (nome.equals("")==true){
		    			sql ="select * from dipendente where mansione='"+mansione+"' ";
		    		}else if (mansione.equals("")==true){
		    			 sql="select * from dipendente where nome='"+nome+"' or cognome='"+nome+"'order by data_assunzione";	
		    		}else{
		    			sql="select * from dipendente where mansione='"+mansione+"' and nome='"+nome+"' ";
		    		}
		    	PreparedStatement pst = connection.prepareStatement(sql);
	    		ResultSet rs=pst.executeQuery(sql);
	    		view.tabella.setModel(DbUtils.resultSetToTableModel(rs));
	    		pst.close();
	    		rs.close();
	    	} catch (SQLException e1) {
	    		
	    		JOptionPane.showMessageDialog(null, "Impossibile cercare il dipendente: inserire il nome/cognome o la mansione!");
	    	}
	    	
	    	
	    	
	    	}
	    	
	    }
	   
	    class CaricaDipendenti_1 implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		
	    		try {
	    			String sql="select * from dipendente where id='"+id+"' ";
	    			PreparedStatement pst = connection.prepareStatement(sql);
	    			ResultSet rs=pst.executeQuery(sql);
	    			view.tabella.setModel(DbUtils.resultSetToTableModel(rs));
	    			pst.close();
	    			rs.close();
	    			} catch (SQLException e1) {
	    		
	    				e1.printStackTrace();
	    			}
	   
	    	}
	    	
	    }
	   
	    class DipendenteListener implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		
	    			String nome;
	    			String sql;
	    			model=view.getDipendente();
	    			nome=model.getNomeDipendente();
	    			
	    			try {
	    				if(nome.equals("")==true){
	    					sql=null;
	    				}else{
	    					sql ="select * from dipendente where nome='"+nome+"' or cognome='"+nome+"'order by data_assunzione";
	    				}
	    				PreparedStatement pst=connection.prepareStatement(sql);
						ResultSet rs=pst.executeQuery(sql);
						view.table1.setModel(DbUtils.resultSetToTableModel(rs));
						pst.close();
		    			rs.close();
						
					} catch (SQLException e2) {
						JOptionPane.showMessageDialog(null, "Impossibile cercare il dipendente: inserire il nome/cognome!");
						
					}             
	    }
	    
	    }
	    
	  
	    class CercaMansioneListener implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    			
	    			String mansione;
	    			String sql;
	    			model=view.getDipendente();
	    			mansione=model.getMansione();
	    			
	    			try {
	    				if(mansione.equals("")==true){
	    					sql=null;
	    				}else{
	    					sql ="select * from dipendente where mansione='"+mansione+"'";
	    				}
	    				
						Statement st=connection.createStatement();
						ResultSet rs=st.executeQuery(sql);
						view.table1.setModel(DbUtils.resultSetToTableModel(rs));
						st.close();
						rs.close();
					} catch (SQLException e2) {
						JOptionPane.showMessageDialog(null, "Impossibile cercare il dipendente: inserire la mansione!");
						
					}
					
					
	                
	    }}
	    
	    
	    class InserisciDipendenteListener implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
                
                String Id_Turno=null;
                
	    		model=view.getDipendente2();

	    		String NomeDipendente;
	    		NomeDipendente=model.getNomeDipendente();
	    		
	    		String CognomeDipendente;
	    		CognomeDipendente=model.getCognomeDipendente();
	    		
	    		String CodiceFisc;
	    		CodiceFisc=model.getCodiceFisc();
	    		
	    		Date AnnoNascita;
	    		AnnoNascita=model.getAnnoNascita();
	    		
	    		
	    		Date Data_Ass;
	    		Data_Ass=model.getData_Ass();
	    		
	    		
	    		String Indirizzo;
	    		Indirizzo=model.getIndirizzo();
	    		
	    		String Email;
	    		Email=model.getEmail();
	    		
	    		
	    		
	    		String Telefono;
	    		Telefono=model.getTelefono();
	    		
	    		Date Data_Lic;
	    		Data_Lic=model.getData_Lic();
	    		
	    		String Mansione;
	    		Mansione=model.getMansione();
	    		
	    		String Nome_Turno;
	    		Nome_Turno=model.getNome_Turno();
	    		
	    	
	    		try{
	    			if(Nome_Turno!="")
	    			{
	    				try {
	    		        	String sq="select id_turno from turno where nome_turno='"+Nome_Turno+"' ";
	    		            Statement stmt = connection.createStatement();
	    		            ResultSet rs1 = stmt.executeQuery(sq);
	    		            
	    		            while (rs1.next()) {
	    		            	Id_Turno=rs1.getString(1);
	    		              
	    		            }
	    		            stmt.close();
	    		            rs1.close();
	    		          
	    		        }catch(SQLException e1) {
	    		        	e1.printStackTrace();
	    		        }
	    		        
	    			}	    				
	    			
	    		
	    		String sql ="insert into dipendente (nome,cognome,cod_fisc,indirizzo,datan,mansione,data_assunzione,id,email,data_licenziamento,telefono,id_turno) values (?,?,?,?,?,?,?,?,?,?,?,?)";
						
				PreparedStatement pst1 =connection.prepareStatement(sql);
				
				if (NomeDipendente.equals("")==true){
					JOptionPane.showMessageDialog(null, "Inserire nome dipendente!");
				}else{
					pst1.setString(1, NomeDipendente);
				}
				if (CognomeDipendente.equals("")==true){
					JOptionPane.showMessageDialog(null, "Inserire cognome dipendente!");
				}else{
					pst1.setString(2, CognomeDipendente);
				}
				if (CodiceFisc.equals("")==true){
					JOptionPane.showMessageDialog(null, "Inserire codice fiscale!");			
				}else if (CodiceFisc.length()==16){
					pst1.setString(3,CodiceFisc);
					}else{
					JOptionPane.showMessageDialog(null, "Codice fiscale errato!");
				}
				if (Indirizzo.equals("")==true){
					JOptionPane.showMessageDialog(null, "Inserire indirizzo");
				}else{
					pst1.setString(4, Indirizzo);
				}
				
				
				pst1.setDate(5, AnnoNascita);
				pst1.setString(6, Mansione);
				pst1.setDate(7, Data_Ass);
				pst1.setString(8, id);
				pst1.setString(9, Email);
					
				
				if(Data_Lic !=null){
					if (Data_Lic.after(Data_Ass)==true) {
						pst1.setDate(10, Data_Lic);		
						}else{
		    					JOptionPane.showMessageDialog(null, "Data licenziamento errata");
		    			}
				}else{
					pst1.setDate(10, Data_Lic);	
				}
				
				pst1.setString(11, Telefono);
				pst1.setString(12, Id_Turno);
				
			    pst1.execute();
				
				JOptionPane.showMessageDialog(null, "Dipendente  inserito!");
				
				view.refreshTabella1(id);
				view.refreshTabella(id);
			    view.refreshForm();
				pst1.close();
			} catch (Exception e2){
				
				JOptionPane.showMessageDialog(null, "Inserire i campi obbligatori o in modo corretto!");
			}
	    }
	    }
	   
	    class ModificaDipendente implements ActionListener {
	    	public void actionPerformed(ActionEvent e){
	
	    		    		
	    		    		String Id_Turno=null;
	    		    		model=view.getDipendente3();

	    		    		String NomeDipendente;
	    		    		NomeDipendente=model.getNomeDipendente();
	    		    		
	    		    		String CognomeDipendente;
	    		    		CognomeDipendente=model.getCognomeDipendente();
	    		    		
	    		    		String CodiceFisc;
	    		    		CodiceFisc=model.getCodiceFisc();
	    		    		
	    		    		Date AnnoNascita;
	    		    		AnnoNascita=model.getAnnoNascita();
	    		    		
	    		    		
	    		    		Date Data_Ass;
	    		    		Data_Ass=model.getData_Ass();
	    		    		
	    		    		
	    		    		String Indirizzo;
	    		    		Indirizzo=model.getIndirizzo();
	    		    		
	    		    		String Email;
	    		    		Email=model.getEmail();
	    		    		
	    		    		
	    		    		
	    		    		String Telefono;
	    		    		Telefono=model.getTelefono();
	    		    		
	    		    		Date Data_Lic;
	    		    		Data_Lic=model.getData_Lic();
	    		    		
	    		    		String Mansione;
	    		    		Mansione=model.getMansione();
	    		    		
	    		    		String Nome_Turno;
	    		    		Nome_Turno=model.getNome_Turno();
	    		    		
	    		    		
	    		    		try{
	    		    
	    		    		if(Nome_Turno!="")
	    		    			{
	    		    			 	try {
	    		    		        	String sq="select id_turno from turno where nome_turno='"+Nome_Turno+"' ";
	    		    		            Statement stmt = connection.createStatement();
	    		    		            ResultSet rs1 = stmt.executeQuery(sq);

	    		    		            while (rs1.next()) {
	    		    		            	Id_Turno=rs1.getString(1);
	    		    		              
	    		    		            }
	    		    		            stmt.close();
	    		    		            rs1.close();
	    		    		            
	    		    		        }catch(SQLException e1) {
	    		    		        	
	    		    		        	e1.printStackTrace();
	    		    		        }
	    		    		        
	    		    			}
	    		    		
	    		    	
	    		
	    		
	    		int row=view.tabella.getSelectedRow();
				String codice_=(view.tabella.getModel().getValueAt(row, 0)).toString();
				String query="UPDATE dipendente set nome=?, cognome=? , cod_fisc=?, indirizzo=?,email=?,"
						+ "datan=?,mansione=?,data_assunzione=?, data_licenziamento=?,telefono=?, id_turno=?  where codice='"+codice_+"' and id='"+id+"'";
				
				
				PreparedStatement pst1=connection.prepareStatement(query);
				if (NomeDipendente.equals("")==true){
					JOptionPane.showMessageDialog(null, "Inserire nome!");
				}else{
					pst1.setString(1, NomeDipendente);
				}
				if (CognomeDipendente.equals("")==true){
					JOptionPane.showMessageDialog(null, "Inserire cognome!");
				}else{
					pst1.setString(2,CognomeDipendente);
				}
				if (CodiceFisc.equals("")==true){
					JOptionPane.showMessageDialog(null, "Inserire codice fiscale!");			
				}else if(CodiceFisc.length()==16){
					pst1.setString(3,CodiceFisc);
					}else{
					JOptionPane.showMessageDialog(null, "Codice fiscale errato!");
				}
				if(Indirizzo.equals("")==true){
					JOptionPane.showMessageDialog(null, "Inserire indirizzo!");
				}else{
					pst1.setString(4, Indirizzo);
				}
				
				pst1.setString(5, Email);

				pst1.setDate(6, AnnoNascita);
				if(Mansione!=""){
					pst1.setString(7, Mansione);

				}else{
					JOptionPane.showMessageDialog(null, "Selezionare una mansione!");
					}
				pst1.setDate(8, Data_Ass);
				
				if(Data_Lic !=null){
					if (Data_Lic.after(Data_Ass)==true) {
						pst1.setDate(9, Data_Lic);		
						}else{
		    					JOptionPane.showMessageDialog(null, "Data licenziamento errata");
		    			}
				}else{
					pst1.setDate(9, Data_Lic);	
				}
				
				
				pst1.setString(10, Telefono);
				pst1.setString(11, Id_Turno);
				pst1.executeUpdate();
				
				JOptionPane.showMessageDialog(null, "Dipendente modificato correttamente!");
				pst1.close();
				view.refreshForm();
				view.refreshTabella(id);
				
					}catch(Exception e1){
						JOptionPane.showMessageDialog(null, "Inserire i campi obbligatori o in modo corretto!");
						
					}
	    		
	    		
	    	  }
	   }
}
	    	
	    

	    	            	
	    		





