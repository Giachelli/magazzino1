package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Model.DipendenteModel;
import Model.LoginModel;
import View.DipendenteView;
import View.Home;
import View.LoginView;
import Model.ProdottoModel;
import Model.TurniModel;
import View.ProdottoView;
import View.TurniView;
import net.proteanit.sql.DbUtils;

/**
 * Classe TurniController.java
 * Questa classe ci permette di implementate, richiamando il model, 
 * tutte le azioni dei pulsanti realizzati nella TurniView.
 * 
 * @author Riccardo  
 * 
 */
public class TurniController extends Home{
	
	private TurniModel model; 
	private TurniView view;
    private ProdottoController theController1;
    private DipendenteController theController2;
	
    
    public TurniController (TurniView view) {
    	
    	this.view = view;
    	view.addCaricaTurnoListener(new CaricaTurno());
        view.addCaricaTurnoListener1(new CaricaTurno1());
        view.addEliminaTurnoListener(new EliminaTurno());
        view.addModificaTurnoListener(new ModificaTurno());
        view.addInserisciTurnoListener(new InserisciTurno());
        view.Logout(new Logout());
    	view.dipendenteView(new dipendenteView());
    	view.turniView(new turniView());
    	view.prodottiView(new prodottiView());
        
        
    	
    }
    
    class turniView implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		

    		TurniView theView = new TurniView();
    		@SuppressWarnings("unused")
			TurniModel theModel= new TurniModel(); 
    		TurniController theController= new TurniController(theView);
    		theController.id=id;
    		theController.label=label;
    		labelLogin.setText(label);
    		theView.frame.add(labelLogin);
    		theView.frame.setVisible(true);
    		view.frame.dispose();
    		
    	}
    }
    
    class prodottiView implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		
    		ProdottoView theView = new ProdottoView();
    		@SuppressWarnings("unused")
    		ProdottoModel theModel= new ProdottoModel(); 
    		theController1= new ProdottoController(theView);
    		theController1.id=id;
    		theController1.label=label;
    		labelLogin.setText(label);
    		theView.frame.add(labelLogin);
    		theView.frame.setVisible(true);
    		view.frame.dispose();
    		
    	}
    }
    
    class dipendenteView implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		
    		DipendenteView theView = new DipendenteView();
    		@SuppressWarnings("unused")
    		DipendenteModel theModel= new DipendenteModel(); 
    		theController2= new DipendenteController(theView);
    		theController2.id=id;
    		theController2.label=label;
    		labelLogin.setText(label);
    		theView.frame.add(labelLogin);
    		theView.frame.setVisible(true);
    		view.frame.dispose();
    	}
    }
   
    
   
    class Logout implements ActionListener {
    	public void actionPerformed(ActionEvent e){
    		
			try {
				connection.close();
				view.frame.dispose();
				
				LoginView theView = new LoginView();
				@SuppressWarnings("unused")
				LoginModel theModel = new LoginModel(); 
				@SuppressWarnings("unused")
				LoginController theController = new LoginController(theView);
				
				theView.frameLogin.setVisible(true);
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
			
    		
    }}
   
    
    class CaricaTurno implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		
    		
        	try {
        		String sql ="select id_turno,nome_turno,lunedi,martedi,mercoledi,giovedi,venerdi,sabato,tot_ore_settimanali from turno where id='"+id+"'";
        		PreparedStatement pst = connection.prepareStatement(sql);
        		ResultSet rs=pst.executeQuery(sql);
        		view.table_2.setModel(DbUtils.resultSetToTableModel(rs));
        		pst.close();
        		rs.close();
        	} catch (SQLException e1) {
        		
        		e1.printStackTrace();
        	}
			
  		  }
    	}
    
   
    class CaricaTurno1 implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		
    		
        	try {
        		String sql ="select id_turno,nome_turno,lunedi,martedi,mercoledi,giovedi,venerdi,sabato,tot_ore_settimanali from turno where id='"+id+"'";
        		PreparedStatement pst = connection.prepareStatement(sql);
        		ResultSet rs=pst.executeQuery(sql);
        		view.table.setModel(DbUtils.resultSetToTableModel(rs));
        		pst.close();
        		rs.close();
        	} catch (SQLException e1) {
        		
        		e1.printStackTrace();
        	}
			
  		  }
    	}
    
 
    class EliminaTurno implements ActionListener {
    	public void actionPerformed(ActionEvent e){
    		int action=JOptionPane.showConfirmDialog
					(null, "Sei sicuro di voler eliminare il turno selezionato?","Elimina", JOptionPane.YES_NO_OPTION);
			if (action==0){
			try{
			
				int row=view.table_2.getSelectedRow();
				String codice_=(view.table_2.getModel().getValueAt(row, 0)).toString();
				
				String query="Delete from turno where id_turno='"+codice_+"'";
				
				PreparedStatement pst=connection.prepareStatement(query);
				pst.execute();
				
				JOptionPane.showMessageDialog(null, "Turno eliminato correttamente!");
				pst.close();
				view.refreshTableTurno(id);
				view.refreshFormTurno();
					}catch(Exception e1){
						JOptionPane.showMessageDialog(null, "Impossibile eliminare: selezionare prima il turno!");
						
				}
			}
    	}

    }
  
    class ModificaTurno implements ActionListener {
    	public void actionPerformed(ActionEvent e){
    		
    			model=view.getTurno();
        	
        		String nome=model.getNomeTurno();
        		String lunedi=model.getLunedi();
        		String martedi=model.getMartedi();
        		String mercoledi=model.getMercoledi();
        		String giovedi=model.getGiovedi();
        		String venerdi=model.getVenerdi();
        		String sabato=model.getSabato();
        		int ore = model.Calcola_ore();
    		
    		try{
    		int row=view.table_2.getSelectedRow();
			String codice_=(view.table_2.getModel().getValueAt(row, 0)).toString();
			String query="UPDATE turno set nome_turno=?, lunedi=? , martedi=?, mercoledi=?,giovedi=?, venerdi=?, sabato=?, tot_ore_settimanali=?"
					+ " where id_turno='"+codice_+"' and id='"+id+"'";
			
			
			PreparedStatement pst=connection.prepareStatement(query);
			if (nome.equals("")==true){
				JOptionPane.showMessageDialog(null, "Inserire nome turno!");
			}else{
				pst.setString(1, nome);
			}
			
			if (lunedi.equals("")==true){
			}else pst.setString(2, lunedi);
			
			if(martedi.equals("")==true){
			}else pst.setString(3, martedi);
			
			if(mercoledi.equals("")==true){
			}else pst.setString(4, mercoledi);
			
			if(giovedi.equals("")==true){
			}else pst.setString(5, giovedi);
			
			if(venerdi.equals("")==true){
			}else pst.setString(6, venerdi);
			
			if(sabato.equals("")==true){
			}else pst.setString(7, sabato);
			
				pst.setInt(8, ore);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(null, "Turno modificato correttamente!");
			pst.close();
			view.refreshTableTurno(id);
			view.refreshFormTurno();
				}catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Inserire i campi obbligatori o in modo corretto!");
					
				}
    	
    		
    }}
  
    class InserisciTurno implements ActionListener {
    	public void actionPerformed(ActionEvent e){
    		
    			model=view.getTurno1();
        	
        		String nome=model.getNomeTurno();
        		String lunedi=model.getLunedi();
        		String martedi=model.getMartedi();
        		String mercoledi=model.getMercoledi();
        		String giovedi=model.getGiovedi();
        		String venerdi=model.getVenerdi();
        		String sabato=model.getSabato();
    		
    		try{
			String query="Insert into turno (nome_turno,lunedi,martedi,mercoledi,giovedi,venerdi,sabato,tot_ore_settimanali, id) values (?,?,?,?,?,?,?,?,?)";

			PreparedStatement pst=connection.prepareStatement(query);
			if (nome.equals("")==true){
				JOptionPane.showMessageDialog(null, "Inserire nome turno!");
			}else{
				pst.setString(1, nome);
			}
			
			if (lunedi.equals("")==true){
			}else pst.setString(2, lunedi);
			
			if(martedi.equals("")==true){
			}else pst.setString(3, martedi);
			
			if(mercoledi.equals("")==true){
			}else pst.setString(4, mercoledi);
			
			if(giovedi.equals("")==true){
			}else pst.setString(5, giovedi);
			
			if(venerdi.equals("")==true){
			}else pst.setString(6, venerdi);
			
			if(sabato.equals("")==true){
			}else pst.setString(7, sabato);
			
				pst.setInt(8, model.Calcola_ore());
				pst.setString(9, id);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(null, "Turno inserito correttamente!");
			pst.close();
			view.refreshTableTurno(id);
			view.refreshFormTurno();
			view.refreshFormTurno1();
				}catch(SQLException e1){
					JOptionPane.showMessageDialog(null, "Inserire i campi obbligatori");
					
				}
    	
    		
    }}
    
}