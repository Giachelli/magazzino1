package Controller;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JLabel;
import com.connectiondb.*;
import Model.LoginModel;
import Model.ProdottoModel;
import View.LoginView;
import View.OspiteView;
import View.ProdottoView;



/**
 * Classe LoginController.java
 * Questa classe implementa l'azione svolta alla pressione del btnLogin, andando a richiamare il model.
 * Per implementare il LoginListener abbiamo bisogno in particolare della funzione booleana checkUser.
 * Essa ci restituisce true o false, attraverso una query sql, se l'username e la password inseriti
 * sono presenti nel database.
 *  
 *     
 * @author Iezzi Valerio
 *
 */
public class LoginController {
    
	private LoginModel model;
	private LoginView view;
	private ProdottoController theController;
    public Connection connection = null;
    private String codice=null;
    public String id=null;
    public JLabel labelLogin;
    public String label;
    
    
    public LoginController(LoginView view){
        
    	this.view = view;
        connection=sqlConnection.dbConnector();
        view.addLoginListener(new LoginListener());
        view.addLogin2Listener(new Login2Listener());
        
        labelLogin = new JLabel();
    	labelLogin.setBounds(143, 7, 61, 16);
    	labelLogin.setFont(new Font("Lucida Grande", Font.BOLD, 16));
    	view.frameLogin.setTitle("Login");
    	
    }
    
    
    class Login2Listener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
        	
        	OspiteView theView = new OspiteView();
        	@SuppressWarnings("unused")
			OspiteController theController = new OspiteController(theView);
        	theView.frameOspite.setVisible(true);
        	view.frameLogin.dispose();
        }
    }
    
    class LoginListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                model = view.getUser();
                label=model.getUserName();
                labelLogin.setText(label);
				
				
				if(checkUser(model)){
                    view.showMessage("Login effettuato con successo!");
                    id=checkid(model);
                    
                    view.frameLogin.dispose();
                    
                    
                    ProdottoView theView = new ProdottoView();
            		@SuppressWarnings("unused")
					ProdottoModel theModel= new ProdottoModel(); 
            		theController= new ProdottoController(theView);
            		
            		
            		theController.id=id;
            		theController.label=label;
            		
            		theView.frame.add(labelLogin);
            		theView.frame.setVisible(true);
            		
                }else{
                	
                    view.showMessage("Username o Passaword errati");
                    
                }                
            } catch (Exception ex) {
                view.showMessage("Nessuna connessione con il db!");
                ex.printStackTrace();
            }
        }
    }
    
    
    public boolean checkUser(LoginModel user) throws Exception {
    		
    		try {
    		String query = "select user,pass from admin where user='"+user.getUserName()+"'and pass='"+user.getPassword()+"'";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            if (rs.next()) {
              return true;
            }
            stmt.close();
            rs.close();
            
    		}catch(SQLException e) {
    			e.printStackTrace();
    		} 
    		return false;
     }
    
    public String checkid(LoginModel user) throws Exception {
    	
    	try {
    		String query = "select id from admin where user='"+user.getUserName()+"'and pass='"+user.getPassword()+"'";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
              codice=rs.getString(1);
             
            }
            stmt.close();
            rs.close();
          
        }catch(SQLException e) {
        	e.printStackTrace();
        }
		return codice; 
        
    }
} 
