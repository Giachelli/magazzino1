package Model;
import java.sql.Date;

/**
 * Classe DipendenteModel.java
 * In questa classe vengono generati i getters e i setters relativi.
 *
 */
public class DipendenteModel {
	private  String NomeDipendente;
	private  String CognomeDipendente;
	private  String CodiceFisc;
	private  String Indirizzo;
	private  String Email;
	private  Date AnnoNascita;
	private  String Mansione;
	private  Date Data_Ass;
	private  Date Data_Lic;
	private  Integer id;
	private  String Telefono;
	private  String Nome_Turno;
	
	
	public DipendenteModel(){
	}
	
	
	public DipendenteModel(String NomeDipendente, String CognomeDipendente, String CodiceFisc, String Indirizzo, 
			String Email, Date AnnoNascita, String Mansione, Date Data_Ass,
			Date Data_Lic, Integer id, String Telefono, String Nome_Turno){
		
		this.NomeDipendente= NomeDipendente;
		this.CognomeDipendente= CognomeDipendente;
		this.CodiceFisc= CodiceFisc;
		this.Indirizzo=Indirizzo;
		this.Email=Email;
		this.AnnoNascita=AnnoNascita;
		this.Mansione= Mansione;
        this.Data_Ass=Data_Ass;
	    this.Data_Lic=Data_Lic;
	    this.id=id;
	    this.Telefono=Telefono;
	    this.Nome_Turno=Nome_Turno;
	    
     }
	
	public DipendenteModel(String NomeDipendente, String Mansione, String Nome_Turno){
		this.NomeDipendente = NomeDipendente;
        this.Mansione=Mansione;
        this.Nome_Turno=Nome_Turno;
        
     }
	
	public DipendenteModel(String NomeDipendente, String Mansione){
		this.NomeDipendente = NomeDipendente;
        this.Mansione=Mansione;
        
	}
	public String getNomeDipendente() {
		return NomeDipendente;
	}

	public void setNomeDipendente(String NomeDipendente) {
		this.NomeDipendente = NomeDipendente;
	}

	public String getCognomeDipendente() {
		return CognomeDipendente;
	}

	public void setCognomeDipendente(String CognomeDipendente) {
		this.CognomeDipendente = CognomeDipendente;
	}

	public String getCodiceFisc() {
		return CodiceFisc;
	}

	public void setCodiceFisc(String CodiceFisc) {
		this.CodiceFisc = CodiceFisc;
	}
	
	
	public String getIndirizzo() {
		return Indirizzo;
	}

	public void setIndirizzo(String Indirizzo) {
		this.Indirizzo = Indirizzo;
	}
	
	public String getEmail() {
		return Email;
	}

	public void setEmail(String Email) {
		this.Email = Email;
	}

	public Date getAnnoNascita() {
		return AnnoNascita;
	}

	public void setAnnoNascita(Date AnnoNascita) {
		this.AnnoNascita = AnnoNascita;
	}

	public String getMansione() {
		return Mansione;
	}

	public void setMansione( String Mansione) {
		this.Mansione= Mansione;
	}
	
	public Date getData_Ass() {
		return Data_Ass;
	}

	public void setData_Ass(Date Data_Ass) {
		this.Data_Ass = Data_Ass;
	}
	
	public Date getData_Lic() {
		return Data_Lic;
	}

	public void setData_Lic(Date Data_Lic) {
		this.Data_Lic = Data_Lic;
	}
	
	public Integer getid() {
		return id;
	}

	public void setid(Integer id)
	{
		this.id=id;
	}
	
	public String getTelefono()
	{
		return Telefono;
	}

	public void setTelefono(String Telefono)
	{
		this.Telefono=Telefono;
	}
	
	public String toString(){
		return this.NomeDipendente;
		
		}
	
	public String toString1(){
		return this.Mansione;
	}
	
	public String getNome_Turno() {
		return Nome_Turno;
	}

	public void setNome_Turno(String nome_Turno) {
		Nome_Turno = nome_Turno;
	}
	

	
}
